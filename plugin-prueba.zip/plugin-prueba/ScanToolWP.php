<?php
/*
Plugin name: ScanToolWP
Description: A simple plugin to display technical information from a website created with WordPress
Author: Juan Cardona.
Version: 0.5
*/

// Call ScanToolWP function to load plugin menu in dashboard
add_action( 'admin_menu', 'ScanToolWP' );



$admin_email = get_option( 'admin_email' );
//echo $admin_email;



//share


add_action("admin_menu", "createMyMenus");

function createMyMenus() {
    add_menu_page("My Menu", "My Menu", 0, "my-menu-slug", "myMenuPageFunction");
    add_submenu_page("my-menu-slug", "My Submenu", "My Submenu", 0, "my-submenu-slug", "mySubmenuPageFunction");
}


function social_share_menu_item()
{
  add_submenu_page("options-general.php", "Social Share", "Social Share", "manage_options", "social-share", "social_share_page"); 
}

add_action("admin_menu", "social_share_menu_item");



function social_share_page()
{
   ?>
      <div class="wrap">
         <h1>About.</h1>
         <th scope="row">Juan Fernando Cardona Z.</th>
         <h2>Activar/Desactivar Redes Sociales</h2>
         <form method="post" action="options.php">
            <?php
               settings_fields("social_share_config_section");
 
               do_settings_sections("social-share");
                
               submit_button(); 



               
            ?>
         </form>
      </div>


      <div class="wrap">
       <h1>Ver Entrada Redes Sociales</h1>

       <form method="post" action="options.php">
       <a href="http://localhost/25-WP/2024/03/24/hola-mundo/"  target="_blank">Redes Sociales</a> <br>
       <a href="http://localhost/25-WP/wp-admin/admin.php?page=extra-post-info"  >Volver</a>
       </form>
    </div>

   <?php
}




function social_share_settings()
{
    add_settings_section("social_share_config_section", "", null, "social-share");
 
    add_settings_field("social-share-facebook", "Do you want to display Facebook share button?", "social_share_facebook_checkbox", "social-share", "social_share_config_section");
    add_settings_field("social-share-twitter", "Do you want to display Instagram share button?", "social_share_twitter_checkbox", "social-share", "social_share_config_section");
    add_settings_field("social-share-linkedin", "Do you want to display LinkedIn share button?", "social_share_linkedin_checkbox", "social-share", "social_share_config_section");
    //add_settings_field("social-share-reddit", "Do you want to display Reddit share button?", "social_share_reddit_checkbox", "social-share", "social_share_config_section");
 
    register_setting("social_share_config_section", "social-share-facebook");
    register_setting("social_share_config_section", "social-share-twitter");
    register_setting("social_share_config_section", "social-share-linkedin");
    register_setting("social_share_config_section", "social-share-reddit");
}
 
function social_share_facebook_checkbox()
{  
   ?>
        <input type="checkbox" name="social-share-facebook" value="1" <?php checked(1, get_option('social-share-facebook'), true); ?> /> Check for Yes
   <?php
}

function social_share_twitter_checkbox()
{  
   ?>
        <input type="checkbox" name="social-share-twitter" value="1" <?php checked(1, get_option('social-share-twitter'), true); ?> /> Check for Yes
   <?php
}

function social_share_linkedin_checkbox()
{  
   ?>
        <input type="checkbox" name="social-share-linkedin" value="1" <?php checked(1, get_option('social-share-linkedin'), true); ?> /> Check for Yes
   <?php
}

function social_share_reddit_checkbox()
{  
   ?>
        <input type="checkbox" name="social-share-reddit" value="1" <?php checked(1, get_option('social-share-reddit'), true); ?> /> Check for Yes
   <?php
}
 
add_action("admin_init", "social_share_settings");




function add_social_share_icons($content)
{
    $html = "<div class='social-share-wrapper'><div class='share-on'>Share on: </div>";

    global $post;

    $url = get_permalink($post->ID);
    $url = esc_url($url);

    if(get_option("social-share-facebook") == 1)
    {
        $html = $html . "<div class='facebook'><a target='_blank' href='https://www.facebook.com/nativapps'>Facebook</a></div>";
    }

    if(get_option("social-share-twitter") == 1)
    {
        $html = $html . "<div class='twitter'><a target='_blank' href='https://www.instagram.com/nativapps'>Instagram</a></div>";
    }

    if(get_option("social-share-linkedin") == 1)
    {
        $html = $html . "<div class='linkedin'><a target='_blank' href='https://www.linkedin.com/company/nativapps-inc'>LinkedIn</a></div>";
    }

    

    $html = $html . "<div class='clear'></div></div>";

    return $content = $content . $html;
}

add_filter("the_content", "add_social_share_icons");



function social_share_style() 
{
    wp_register_style("social-share-style-file", plugin_dir_url(__FILE__) . "style.css");
    wp_enqueue_style("social-share-style-file");
}

add_action("wp_enqueue_scripts", "social_share_style");





//fin share


//custom

/*add_action( 'init', 'crear_un_cpt' );
function crear_un_cpt() {
     $args = array(
     'public' => true,
     'label' => 'Libros'
);
register_post_type( 'libro', $args );
}
*/

    /* Custom Post Type Start */
    function create_posttype() {
    register_post_type( 'news',
    // CPT Options
    array(
    'labels' => array(
    'name' => __( 'news' ),
    'singular_name' => __( 'News' )
    ),
    'public' => true,
    'has_archive' => false,
    'rewrite' => array('slug' => 'news'),
    )
    );
    }
    // Hooking up our function to theme setup
    add_action( 'init', 'create_posttype' );
    /* Custom Post Type End */



        /*Custom Post type start*/
        function cw_post_type_news() {
          $supports = array(
          'title', // post title
          'editor', // post content
          'author', // post author
          'thumbnail', // featured images
          'excerpt', // post excerpt
          'custom-fields', // custom fields
          'comments', // post comments
          'revisions', // post revisions
          'post-formats', // post formats
          );
          $labels = array(
          'name' => _x('libros', 'plural'),
          'singular_name' => _x('libros', 'singular'),
          'menu_name' => _x('Libros', 'admin menu'),
          'name_admin_bar' => _x('libros', 'admin bar'),
          'add_new' => _x('Agregar Nuevo', 'add new'),
          'add_new_item' => __('Agregar nuevo libro'),
          'new_item' => __('Nuevo libro'),
          'edit_item' => __('Editar libro'),
          'view_item' => __('Ver libro'),
          'all_items' => __('Todos los libros'),
          'search_items' => __('Search news'),
          'not_found' => __('No news found.'),
          );
          $args = array(
          'supports' => $supports,
          'labels' => $labels,
          'public' => true,
          'query_var' => true,
          'rewrite' => array('slug' => 'news'),
          'has_archive' => true,
          'hierarchical' => false,
          'menu_icon' => 'dashicons-book-alt',
          );
          register_post_type('news', $args);
          }
          add_action('init', 'cw_post_type_news');
          /*Custom Post type end*/


//fin custom



// Páginas Publicadas
$args = array(
  'sort_order' => 'asc',
  'sort_column' => 'post_title',
  'hierarchical' => 1,
  'exclude' => '',
  'include' => '',
  'meta_key' => '',
  'meta_value' => '',
  'authors' => '',
  'child_of' => 0,
  'parent' => -1,
  'exclude_tree' => '',
  'number' => '',
  'offset' => 0,
  'post_type' => 'page',
  'post_status' => 'publish'
); 
$pages = get_pages($args); // get all pages based on supplied args

foreach($pages as $page){ // $pages is array of object
 $page_template = get_post_meta($page->ID, '_wp_page_template', true); // Page template stored in "_wp_page_template"

 //echo $page_template;


}



// Create WordPress admin menu
function ScanToolWP(){

  $page_title = 'WordPress ScanToolWP';
  $menu_title = 'ScanToolWP';
  $capability = 'manage_options';
  $menu_slug  = 'extra-post-info';
  $function   = 'extra_post_info_page';
  $icon_url   = 'dashicons-media-code';
  $position   = 4;

  add_menu_page( $page_title,
                 $menu_title,
                 $capability,
                 $menu_slug,
                 $function,
                 $icon_url,
                 $position );

  // Call update_extra_post_info function to update database
  add_action( 'admin_init', 'update_extra_post_info' );

}

// Create function to register plugin settings in the database
function update_extra_post_info() {
  register_setting( 'extra-post-info-settings', 'extra_post_info' );
}

// Create WordPress plugin page
function extra_post_info_page(){
?>
  <h1>WordPress ScanToolWP</h1>
  <form method="post" action="options.php">
    <?php settings_fields( 'extra-post-info-settings' ); ?>
    <?php do_settings_sections( 'extra-post-info-settings' ); ?>
    

    <table class="form-table">
    <tr valign="top">
      <th scope="row">Nombre del sitio:</th>
      <td><input type="text"  name="extra_post_info" value="<?php echo get_option('blogname'); ?>"/></td>
      </tr>
      <tr valign="top">
      <th scope="row">Url de instalación:</th>
      <td><input type="text"  name="extra_post_info" value="<?php echo get_option('home'); ?>"/></td>
      </tr>
      <tr valign="top">
      <th scope="row">Url de Wordpress:</th>
      <td><input type="text"  name="extra_post_info" value="<?php echo get_option('siteurl'); ?>"/></td>
      </tr>

      <tr valign="top">
      <th scope="row">Version de Wordpress:</th>
      <?php/* echo bloginfo('version');*/?>     

      <td><input type="text"  name="extra_post_info" value="<?php echo bloginfo('version'); ?>"/></td>
      </tr>


      <tr valign="top">
      <th scope="row">Template Instalado:</th>
      <td><input type="text"  name="extra_post_info" value="<?php echo get_option('template'); ?>"/></td>
      </tr>




      <tr valign="top">
      <th scope="row">Número de Páginas Publicadas</th>
      <?php // Get total number of pages published
	    $count_pages = wp_count_posts('page');
	    $total_pages = $count_pages->publish;
	    //echo $total_pages . ' pages. ';
      //echo $total_pages . ' pages. ';
      ?>
      <td><input type="text"  name="extra_post_info" value="<?php echo $total_pages . ' pages. '; ?>"/></td>
      </tr>



      <tr valign="top">
      <th scope="row">Número de Blogs Publicados</th>
      <?php // Get total number of pages published
	    

      $total = wp_count_posts()->publish;
      //echo 'Total Posts: ' . $total;
        

      ?>
      <td><input type="text"  name="extra_post_info" value="<?php echo $total . ' pages. '; ?>"/></td>
      </tr>



      
<?php

$template_path = get_post_meta(get_the_ID(), '_wp_page_template', true);
$templates = wp_get_theme()->get_page_templates();
echo $templates[$template_path];





 /*
$theme_data = wp_get_theme();
echo $theme_data->get( 'Name' );        // Theme name as given in style.css
echo $theme_data->get( 'ThemeURI' );
echo $theme_data->get( 'Description' );
echo $theme_data->get( 'Author' );
echo $theme_data->get( 'AuthorURI' );
echo $theme_data->get( 'Version' );
echo $theme_data->get( 'Template' );
echo $theme_data->get( 'Status' );
echo $theme_data->get( 'Tags' );
echo $theme_data->get( 'TextDomain' );
echo $theme_data->get( 'DomainPath' );
 
*/
      
      ?>


      </tr>
      <tr valign="top">
      <th scope="row">Url Template:</th>
      <td><input type="text"  name="extra_post_info" value="<?php echo get_option('template_directory'); echo get_template_directory_uri(); ?> "/></td>
      </tr>
      



      <tr valign="top">
      <th scope="row">Correo Admin:</th>
      <td><input type="text"  name="extra_post_info" value="<?php echo get_option('admin_email'); ?>"/></td>
      </tr>
     
    


    </table>
    <h1>Página About:</h1>
    
    <a href="http://localhost/25-WP/wp-admin/options-general.php?page=social-share">About</a> 


  <?php /*submit_button();*/ ?>
  </form>
<?php
}








// Plugin logic for adding extra info to posts
if( !function_exists("extra_post_info") )
{
  function extra_post_info($content)
  {
    $extra_info = get_option('extra_post_info');
    return $content . $extra_info;
  }

// Apply the extra_post_info function on our content  
add_filter('the_content', 'extra_post_info');
}




    




?>






